# Bonus: elm-phoenix Package Version

This code in this directory, specifically the `bingo_hall` Phoenix application, uses the [elm-phoenix](https://github.com/saschatimme/elm-phoenix) Elm package rather than the 
[elm-phoenix-socket](https://github.com/fbonetti/elm-phoenix-socket) package.
