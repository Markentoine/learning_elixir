// Sets up the button that copies the game URL to the clipboard.
//
// See https://clipboardjs.com/

new Clipboard("#copy-game-url")
