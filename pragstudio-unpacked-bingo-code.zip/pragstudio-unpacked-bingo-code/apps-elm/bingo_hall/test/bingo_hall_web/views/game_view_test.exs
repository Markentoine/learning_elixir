defmodule BingoHallWeb.GameViewTest do
  use BingoHallWeb.ConnCase, async: true
end
