defmodule BingoHallWeb.LayoutViewTest do
  use BingoHallWeb.ConnCase, async: true
end
