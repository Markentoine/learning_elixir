defmodule BingoHallWeb.SessionViewTest do
  use BingoHallWeb.ConnCase, async: true
end
