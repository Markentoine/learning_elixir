defmodule BingoHallWeb.SessionView do
  use BingoHallWeb, :view
end
