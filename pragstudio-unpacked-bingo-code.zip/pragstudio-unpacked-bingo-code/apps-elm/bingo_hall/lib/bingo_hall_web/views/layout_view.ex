defmodule BingoHallWeb.LayoutView do
  use BingoHallWeb, :view
end
