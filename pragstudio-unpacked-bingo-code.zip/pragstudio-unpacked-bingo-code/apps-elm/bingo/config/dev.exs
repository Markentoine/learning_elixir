use Mix.Config

config :logger, level: :info