use Mix.Config

config :logger, level: :warn