defmodule Servy do
  def hello(name) do
    "Howdy, #{name}!"
  end
end

# IO.puts Servy.hello("Elixir")
